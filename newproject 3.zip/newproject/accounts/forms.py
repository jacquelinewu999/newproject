from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)  # Email is now required

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']  # Include email, password1, and password2

    def save(self, commit=True):
        # This saves the user with the provided data, including the email
        user = super().save(commit=False)  # Using super() to avoid calling the parent method directly
        user.email = self.cleaned_data['email']  # Set the email field
        if commit:
            user.save()  # Save the user instance if commit is True
        return user

