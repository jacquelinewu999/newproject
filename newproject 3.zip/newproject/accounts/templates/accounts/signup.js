document.addEventListener("DOMContentLoaded", () => {
    console.log("Sign Up page loaded!");

    const form = document.querySelector("form");
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        const username = document.getElementById("username").value;
        const email = document.getElementById("email").value;
        const password1 = document.getElementById("password1").value;
        const password2 = document.getElementById("password2").value;

        if (!username || !email || !password1 || !password2) {
            alert("Please fill in all fields.");
            return;
        }

        if (password1 !== password2) {
            alert("Passwords do not match!");
            return;
        }

        console.log("Sign up attempt:", { username, email });
        alert("Sign up successful!");
        form.submit(); // Submit the form after validation
    });
});
