document.addEventListener("DOMContentLoaded", () => {
    console.log("Sign In page loaded!");

    const form = document.querySelector("form");
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        if (!email || !password) {
            alert("Please fill in all fields.");
            return;
        }

        console.log("Sign in attempt:", { email, password });
        alert("Sign in successful!");
        form.submit(); // Submit the form after validation
    });
});
