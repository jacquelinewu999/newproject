function startTask(taskType) {
    alert(`Starting ${taskType} task!`);
    // You can implement navigation or task-specific logic here.
}
