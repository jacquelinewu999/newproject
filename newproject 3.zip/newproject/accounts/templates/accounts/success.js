// script.js

// Example for further dynamic interaction (optional)
document.querySelectorAll('.button').forEach(button => {
    button.addEventListener('click', () => {
        console.log('Button clicked:', button.textContent);
    });
});
