from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('signin/', views.signin, name='signin'),
    path('logout/', views.logout_view, name='logout'),
    path('admin_page/', views.admin_page, name='admin_page'),
    path('student_page/', views.student_page, name='student_page'),
    path('upload/', views.upload_assignment, name='upload_assignment'),  # Make sure this is active
    # path('chat_with_gpt/', views.chat_with_gpt, name='chat_with_gpt'),
]
