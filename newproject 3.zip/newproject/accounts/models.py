from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission

class User(AbstractUser):
    # override the default 'groups' M2M, give it a custom related_name
    groups = models.ManyToManyField(
        Group,
        related_name='accounts_user_set',  # <-- new related_name
        blank=True,
        help_text='The groups this user belongs to.',
        verbose_name='groups',
    )
    # override the default 'user_permissions' M2M, give it a custom related_name
    user_permissions = models.ManyToManyField(
        Permission,
        related_name='accounts_user_permissions_set',  # <-- new related_name
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions',
    )

# Assignment model for storing the uploaded files
class Assignment(models.Model):
    title       = models.CharField(max_length=255)
    description = models.TextField()
    upload      = models.FileField(upload_to='assignments/')
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)
    student     = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assignments')
    
    def __str__(self):
        return self.title
