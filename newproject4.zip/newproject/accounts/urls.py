from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('signin/', views.signin, name='signin'),
    path('logout/', views.logout_view, name='logout'),
    path('admin_page/', views.admin_page, name='admin_page'),
    path('student_page/', views.student_page, name='student_page'),
    path('upload/', views.upload_assignment, name='upload_assignment'),
    path('upload_hw/', views.upload_hw_page, name='upload_hw'),       # HW1 + HW2 ✅
    path('receive_hw/', views.receive_hw, name='receive_hw'),         # for HW4 later

]
