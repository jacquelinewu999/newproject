from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import SignUpForm
from django.contrib import messages
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from docx import Document
import requests

# Signup view to register users
def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Registration successful! You can now log in.')
            return redirect('signin')
    else:
        form = SignUpForm()

    return render(request, 'accounts/signup.html', {'form': form})

# Signin view to authenticate and log users in
def signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if user.is_staff:
                return redirect('admin_page')
            else:
                return redirect('student_page')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'accounts/signin.html')

# Logout view
def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('home')

# Admin page view
def admin_page(request):
    return render(request, 'accounts/admin_page.html')

# Student page view
def student_page(request):
    return render(request, 'accounts/student_page.html')

# Home page view
def home(request):
    return render(request, 'accounts/home.html')

# Upload assignment view with Ollama feedback
def upload_assignment(request):
    if request.method == 'POST' and request.FILES['docx_file']:
        docx_file = request.FILES['docx_file']
        fs = FileSystemStorage()
        filename = fs.save(docx_file.name, docx_file)
        file_path = fs.path(filename)

        # Read .docx file contents
        document = Document(file_path)
        full_text = '\n'.join([para.text for para in document.paragraphs])

        # Get feedback from Ollama
        feedback = call_ollama(full_text)

        return render(request, 'accounts/feedback.html', {
            'feedback': feedback,
            'filename': docx_file.name,
        })

    return render(request, 'accounts/upload.html')

# Call the local Ollama API with student text
def call_ollama(text):
    try:
        response = requests.post(
            'http://localhost:11434/api/generate',
            json={
                "model": "llama3",
                "prompt": f"Please provide detailed feedback on this student assignment:\n\n{text}"
            }
        )
        result = response.json()
        return result.get("response", "No feedback received.")
    except Exception as e:
        return f"Error contacting Ollama: {e}"


def upload_hw_page(request):
    return render(request, 'accounts/Upload_HW.html')




import io
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def receive_hw(request):
    if request.method == 'POST':
        try:
            # Read the blob from request body
            docx_blob = request.body
            docx_file = io.BytesIO(docx_blob)

            # Use python-docx to read the Word content
            document = Document(docx_file)
            full_text = '\n'.join([para.text for para in document.paragraphs])

            # Call Ollama to get feedback
            feedback = call_ollama(full_text)

            return JsonResponse({'feedback': feedback})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    return JsonResponse({'error': 'Invalid request'}, status=400)
