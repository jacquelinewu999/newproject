from django.contrib import admin
from .models import User, Assignment

# Register the models with the Django admin site
admin.site.register(User)
admin.site.register(Assignment)

