document.addEventListener("DOMContentLoaded", () => {
    console.log("Home page loaded!");
});
