import openai

print("Starting script...")

# Set your OpenAI API key here
openai.api_key = "sk-proj-joQjCUPhKG_lXjwHIy_hfUyfw8tfTJe6gUkJwAryCiGAxsqttI55JeltbJ7fB8aR5NhhEJ12URT3BlbkFJo02ln_kVnPlKJGMnGK6vaLElwwJUbY83ztIJaXXXXtBA251iqAvF7NSL0Ff83itmdlseNzrr8A"

try:
    print("Sending request to OpenAI...")
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": "Say hello to me!"}],
        max_tokens=5
    )
    print("Response:", response.choices[0].message.content.strip())
except Exception as e:
    print("An error occurred:", e)
