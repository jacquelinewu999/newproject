import subprocess
from docx import Document

# Step 1: Read the Word file
doc = Document("input.docx")
text = "\n".join([para.text for para in doc.paragraphs])

# Step 2: Add instruction prefix
instruction = "你是一個專業的老師，以下是學生的作業內容，請給予評價：\n"
prompt = instruction + text

# Step 3: Send to Ollama
try:
    result = subprocess.run(
        ["ollama", "run", "llama3"],
        input=prompt,
        text=True,
        capture_output=True,
        timeout=30
    )

    print("Ollama says:\n")
    print(result.stdout)

except Exception as e:
    print(f"Error: {e}")