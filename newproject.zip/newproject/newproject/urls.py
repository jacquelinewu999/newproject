from django.contrib import admin
from django.urls import path, include
from accounts import views  # Make sure your views are properly imported

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", views.home, name="home"),  # Home page
    path('accounts/', include('accounts.urls')),  # Include URLs from accounts app
]
