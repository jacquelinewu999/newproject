from django.db import models
from django.contrib.auth.models import AbstractUser

# Custom User model if needed
class User(AbstractUser):
    # You can add any custom fields here if needed (e.g., profile picture, phone number)
    pass

# Assignment model for storing the uploaded files
class Assignment(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    upload = models.FileField(upload_to='assignments/')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assignments')
    
    def __str__(self):
        return self.title

