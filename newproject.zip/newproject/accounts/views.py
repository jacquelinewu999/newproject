from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import SignUpForm
from django.contrib import messages


from django.shortcuts import render

def upload_assignment(request):
    return render(request, 'upload.html')


# Signup view to register users
def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Registration successful! You can now log in.')
            return redirect('signin')  # Redirecting to sign-in page after registration
    else:
        form = SignUpForm()

    return render(request, 'accounts/signup.html', {'form': form})

# Signin view to authenticate and log users in
def signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)  # Log the user in
            
            # Redirect user to different pages based on staff status
            if user.is_staff:
                return redirect('admin_page')  # Admin users go here
            else:
                return redirect('student_page')  # Regular users go here
        else:
            messages.error(request, 'Invalid username or password.')  # Error if invalid login
    return render(request, 'accounts/signin.html')

# Logout view to log users out
def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('home')  # Redirecting to home after logout

# Admin page view (for staff users)
def admin_page(request):
    return render(request, 'accounts/admin_page.html')

# Student page view (for regular users)
def student_page(request):
    return render(request, 'accounts/student_page.html')

# Home page view (for everyone)
def home(request):
    return render(request, 'accounts/home.html')

