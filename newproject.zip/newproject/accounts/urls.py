from django.urls import path
from . import views  # Import the views from the accounts app

urlpatterns = [
    path('signup/', views.signup, name='signup'),  # Sign-up page
    path('signin/', views.signin, name='signin'),  # Sign-in page
    path('logout/', views.logout_view, name='logout'),  # Log-out view
    path('admin_page/', views.admin_page, name='admin_page'),  # Admin dashboard
    path('student_page/', views.student_page, name='student_page'),  # Student dashboard
    # path('upload/', views.upload_assignment, name='upload_assignment'),  # Upload assignments
]

