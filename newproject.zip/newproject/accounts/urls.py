from django.urls import path
from accounts import views 

urlpatterns = [
    path('signup/', views.signup, name='signup'),  
    path('signin/', views.signin, name='signin'),  
    path('admin_page/', views.admin_page, name='admin_page'), 
    path('student_page/', views.student_page, name='student_page'), 
]
