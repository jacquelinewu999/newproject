function viewAssignments() {
    window.location.href = "student_assignments_list.html";
}

function viewGrades() {
    window.location.href = "student_grades.html";
}
