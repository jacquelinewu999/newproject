import mysql.connector

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",           # If running locally, keep as 'localhost'
    user="root",                # Replace with your MySQL username (default is 'root')
    password="newpassword",  # Replace with your MySQL password
    database="online_course_db"  # Ensure this matches your database name
)

# Create a cursor object to execute SQL queries
cursor = conn.cursor()

print("✅ Connected to MySQL successfully!")

# Close the cursor and connection
cursor.close()
conn.close()


